
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';

function ProdutoList() {
  const [produtos, setProdutos] = useState([]);

  useEffect(() => {
    api.get('/produtos')
      .then(response => setProdutos(response.data))
      .catch(error => console.error(error));
  }, []);

  const deleteProduto = (id) => {
    api.delete(`/produtos/${id}`)
      .then(() => setProdutos(produtos.filter(produto => produto.id !== id)))
      .catch(error => console.error(error));
  };

  return (
    <div>
      <h1>Produtos</h1>
      <Link to="/produtos/novo">Adicionar Produto</Link>
      <ul>
        {produtos.map(produto => (
          <li key={produto.id}>
            <Link to={`/produtos/${produto.id}`}>{produto.nome}</Link>
            <button onClick={() => deleteProduto(produto.id)}>Excluir</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ProdutoList;
