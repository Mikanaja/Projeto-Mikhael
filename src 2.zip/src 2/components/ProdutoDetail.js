
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Link, useParams } from 'react-router-dom';

function ProdutoDetail() {
  const [produto, setProduto] = useState(null);
  const { id } = useParams();

  useEffect(() => {
    api.get(`/produtos/${id}`)
      .then(response => setProduto(response.data))
      .catch(error => console.error(error));
  }, [id]);

  if (!produto) return <div>Carregando...</div>;

  return (
    <div>
      <h1>{produto.nome}</h1>
      <p>Preço: {produto.preco}</p>
      <Link to={`/produtos/${produto.id}/editar`}>Editar</Link>
    </div>
  );
}

export default ProdutoDetail;
