
import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { useHistory, useParams } from 'react-router-dom';

function ProdutoForm() {
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const { id } = useParams();
  const history = useHistory();

  useEffect(() => {
    if (id) {
      api.get(`/produtos/${id}`)
        .then(response => {
          setNome(response.data.nome);
          setPreco(response.data.preco);
        })
        .catch(error => console.error(error));
    }
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const produto = { nome, preco };

    if (id) {
      api.put(`/produtos/${id}`, produto)
        .then(() => history.push('/'))
        .catch(error => console.error(error));
    } else {
      api.post('/produtos', produto)
        .then(() => history.push('/'))
        .catch(error => console.error(error));
    }
  };

  return (
    <div>
      <h1>{id ? 'Editar Produto' : 'Adicionar Produto'}</h1>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Nome</label>
          <input type="text" value={nome} onChange={(e) => setNome(e.target.value)} required />
        </div>
        <div>
          <label>Preço</label>
          <input type="number" value={preco} onChange={(e) => setPreco(e.target.value)} required />
        </div>
        <button type="submit">Salvar</button>
      </form>
    </div>
  );
}

export default ProdutoForm;
