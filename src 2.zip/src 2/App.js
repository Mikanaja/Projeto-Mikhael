
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import ProdutoList from './components/ProdutoList';
import ProdutoForm from './components/ProdutoForm';
import ProdutoDetail from './components/ProdutoDetail';

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={ProdutoList} />
        <Route path="/produtos/novo" component={ProdutoForm} />
        <Route path="/produtos/:id" component={ProdutoDetail} />
        <Route path="/produtos/:id/editar" component={ProdutoForm} />
      </Switch>
    </Router>
  );
}

export default App;
